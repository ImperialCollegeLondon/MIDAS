
package Bio::Metadata::Reader;

# ABSTRACT: class for reading manifests

use Moose;
use namespace::autoclean;

use Text::CSV_XS;
use Digest::MD5;

use Bio::Metadata::Config;
use Bio::Metadata::Manifest;


#-------------------------------------------------------------------------------

# public attributes

has 'config' => (
  is       => 'rw',
  isa      => 'Bio::Metadata::Config',
  required => 1,
);


#-------------------------------------------------------------------------------
#- public methods --------------------------------------------------------------
#-------------------------------------------------------------------------------


sub read_csv {
  my ( $self, $file ) = @_;

  die "ERROR: no input file given"          unless defined $file;
  die "ERROR: no such input file ('$file')" unless -e $file;

  # get the header row from the config
  my $header = substr( $self->config->{header_row} || '', 0, 20 );

  # add a flag to Text::CSV_XS to tell it to parse blank fields in the CSV
  # as undef, rather than "". This is important because when we come to load
  # the row into a DB, DBIC needs empty fields to be undef so that they get
  # correctly translated as NULL in the SQL.
  # NOTE: this switch doesn't seem to work with Text::CSV, only with the
  # XS version.
  my $csv = Text::CSV_XS->new( { blank_is_undef => 1 } );
  open my $fh, '<:encoding(utf8)', $file
    or die "ERROR: problems reading input CSV file: $!";

  my $manifest = Bio::Metadata::Manifest->new( config => $self->config );

  # calculate an MD5 digest for the file
  my $digest = Digest::MD5->new;

  my $row_num = 0;

  ROW: while ( my $row_string = <$fh> ) {
    $row_num++;

    $digest->add($row_string);

    # try to skip the header row, if present, and blank rows
    if ( $row_num == 1 and ( $row_string =~ m/^$header/ or $row_string =~ m/^\,+$/ ) ) {
      next ROW;
    }

    # skip the empty rows that excel likes to include in CSVs
    next ROW if $row_string =~ m/^,+[\r\n]*$/;

    # the current row should now be a data row, so try parsing it
    $csv->parse($row_string)
      or die "ERROR: could not parse row $row_num\n";

    my @raw_values = $csv->fields;
    $manifest->add_row( \@raw_values );
  }

  $manifest->md5( $digest->hexdigest );

  return $manifest;
}

#-------------------------------------------------------------------------------
#- private methods -------------------------------------------------------------
#-------------------------------------------------------------------------------

# private method

#-------------------------------------------------------------------------------

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

Bio::Metadata::Reader - class for reading manifests

=head1 VERSION

version 1.150560

=head1 ATTRIBUTES

=head2 config

A reference to a L<Bio::Metadata::Config> configuration object. This config
object will be passed to all L<Bio::Metadata::Manifest> objects created by this
reader.

Setting a new configuration after instantiation will only affect manifests
created after that point; previously generated manifests will retain their
reference to the original config object.

=head1 NAME

Bio::Metadata::Reader

=head1 CONTACT

path-help@sanger.ac.uk

=head1 METHODS

=head2 read_csv($file)

Reads a manifest from the given file and returns a L<Bio::Metadata::Manifest>.
As the file is read an MD5 checksum is generated and set on the
L<Bio::Metadata::Manifest|Manifest>. We rely on the
L<Bio::Metadata::Manifest|Manifest> itself to create a UUID.

=head1 AUTHOR

John Tate <jt6@sanger.ac.uk>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2014 by Wellcome Trust Sanger Institute.

This is free software, licensed under:

  The GNU General Public License, Version 3, June 2007

=cut
