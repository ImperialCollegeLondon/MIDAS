
package Bio::Metadata::Validator::Plugin::Bool;

# ABSTRACT: validation plugin for validating booleans

use Moose;
use namespace::autoclean;

with 'MooseX::Role::Pluggable::Plugin',
     'Bio::Metadata::Validator::PluginRole';

sub validate {
  my ( $self, $value ) = @_;

  return ( $value =~ m/^(1|true|yes|0|false|no)$/i ) ? 1 : 0;
}

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

Bio::Metadata::Validator::Plugin::Bool - validation plugin for validating booleans

=head1 VERSION

version 1.150560

=head1 AUTHOR

John Tate <jt6@sanger.ac.uk>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2014 by Wellcome Trust Sanger Institute.

This is free software, licensed under:

  The GNU General Public License, Version 3, June 2007

=cut
