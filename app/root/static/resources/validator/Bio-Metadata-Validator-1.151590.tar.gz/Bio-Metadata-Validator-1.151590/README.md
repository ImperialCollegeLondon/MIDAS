Bio-Metadata-Validator
======================

Validate a genome metadata manifest against a checklist
