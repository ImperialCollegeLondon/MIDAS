
package Bio::Metadata::Validator::Plugin::Int;

# ABSTRACT: validation plugin for validating integers

use Moose;
use namespace::autoclean;

use MooseX::Types::Moose qw( Int );

with 'MooseX::Role::Pluggable::Plugin',
     'Bio::Metadata::Validator::PluginRole';

sub validate {
  my ( $self, $value, $field_definition ) = @_;

  return 0 unless is_Int($value);
  
  if ( $field_definition and ref $field_definition eq 'HASH' ) {
    my $max = $field_definition->{max};
    my $min = $field_definition->{min};

    return 0 if ( defined $max and $value > $max );
    return 0 if ( defined $min and $value < $min );
  }

  return 1;
}

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

Bio::Metadata::Validator::Plugin::Int - validation plugin for validating integers

=head1 VERSION

version 1.151590

=head1 AUTHOR

John Tate <jt6@sanger.ac.uk>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2014 by Wellcome Trust Sanger Institute.

This is free software, licensed under:

  The GNU General Public License, Version 3, June 2007

=cut
