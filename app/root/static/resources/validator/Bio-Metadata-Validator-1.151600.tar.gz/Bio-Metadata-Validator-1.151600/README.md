Bio-Metadata-Validator
======================

[![Build Status](https://travis-ci.org/sanger-pathogens/Bio-Metadata-Validator.svg)](https://travis-ci.org/sanger-pathogens/Bio-Metadata-Validator)

Validate a genome metadata manifest against a checklist
