
package Bio::Metadata::Validator::Plugin::Enum;

# ABSTRACT: validation plugin for validating fields against a set of possible values

use Moose;
use namespace::autoclean;

with 'MooseX::Role::Pluggable::Plugin',
     'Bio::Metadata::Validator::PluginRole';

sub validate {
  my ( $self, $value, $field_definition ) = @_;

  my $values = $field_definition->{values};
  my %values = map { $_ => 1 } @$values;

  return defined $values{$value} ? 1 : 0;
}

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

Bio::Metadata::Validator::Plugin::Enum - validation plugin for validating fields against a set of possible values

=head1 VERSION

version 1.151210

=head1 AUTHOR

John Tate <jt6@sanger.ac.uk>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2014 by Wellcome Trust Sanger Institute.

This is free software, licensed under:

  The GNU General Public License, Version 3, June 2007

=cut
