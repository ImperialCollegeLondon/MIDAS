
package Bio::Metadata::Sample;

# ABSTRACT: class for working with sample metadata

use Moose;
use namespace::autoclean;


#-------------------------------------------------------------------------------

# public attributes


# =attr my_attribute
#
# description
#
# =cut

# private attributes

#---------------------------------------

# constructor

# sub BUILD {
#   my $self = shift;
#
# }

#-------------------------------------------------------------------------------
#- public methods --------------------------------------------------------------
#-------------------------------------------------------------------------------


# public method

#-------------------------------------------------------------------------------
#- private methods -------------------------------------------------------------
#-------------------------------------------------------------------------------

# private method

#-------------------------------------------------------------------------------

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

Bio::Metadata::Sample - class for working with sample metadata

=head1 VERSION

version 1.151210

=head1 NAME

Bio::Metadata::Sample

=head1 CONTACT

path-help@sanger.ac.uk

=head1 METHODS

=head1 AUTHOR

John Tate <jt6@sanger.ac.uk>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2014 by Wellcome Trust Sanger Institute.

This is free software, licensed under:

  The GNU General Public License, Version 3, June 2007

=cut
